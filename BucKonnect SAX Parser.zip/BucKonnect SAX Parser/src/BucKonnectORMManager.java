public class BucKonnectORMManager {
	public static void main(String[] args) throws Exception {

		BucKonnectDOMParser domParser = new BucKonnectDOMParser();
		domParser.parseXML("BucKonnectData.xml");

	}
}